 
# Price_Comparison_Website  



 A PHP based website that provides price comparison over various online shopping website such as Flipkart , Amazon and Snapdeal to provide best price for the same product using web scraping (PHP simple DOM) . 


## Features 

-  Search bar to search products over various websites.
-  Websites include Amazon, Flipkart and Snapdeal
- Latency from the point of clicking from search button to getting results is less than 5 seconds.
-  Visit to site button ,provides direct redirection towards the clicked website.
- Supports multi-word queries in Search bar.
- Built on PHP Simple DOM web scraping platform.






### Installing

```
extract in ..xampp/htdocs and run on localhost
```
